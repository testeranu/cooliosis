import axios from 'axios';
import Head from 'next/head';
import config from '../config';

export default function ArticlePage({ article }) {
  if (!article) return <div>Article not found</div>;

  const { attributes } = article;

  return (
    <div className={`${attributes.containerStyles || 'container mx-auto px-4 py-8 max-w-3xl'}`}>
      <Head>
        <title>{attributes.MetTTitle || attributes.Title}</title>
        <meta name="description" content={attributes.MetaDescription} />
        {attributes.CanonicalURL && (
          <link rel="canonical" href={`https://${attributes.CanonicalURL}${attributes.urlSlug}`} />
        )}
        {attributes.Schema && (
          <script type="application/ld+json">{attributes.Schema}</script>
        )}
      </Head>

      <main>
        <header className={attributes.headerStyles || 'mb-8'}>
          <h1 className="text-4xl font-bold mb-2 text-gray-800">{attributes.H1 || attributes.Title}</h1>
          {attributes.Title !== attributes.H1 && <h2 className="text-2xl font-semibold text-gray-700">{attributes.Title}</h2>}
        </header>

        <div className={attributes.bodyStyles || 'prose max-w-none'}>
          <p className={attributes.paragraphStyles || 'text-lg mb-4 text-gray-600'}>{attributes.Paragraph}</p>
          {attributes.Markdown && (
            <div dangerouslySetInnerHTML={{ __html: attributes.Markdown }} />
          )}
        </div>
      </main>

      <footer className="mt-8 text-sm text-gray-500">
        <p>Last updated: {new Date(attributes.updatedAt).toLocaleDateString()}</p>
      </footer>
    </div>
  );
}

export async function getStaticPaths() {
  try {
    const res = await axios.get(config.API_URL, {
      headers: {
        Authorization: `Bearer ${config.API_TOKEN}`
      }
    });

    const articles = res.data.data;
    const filteredArticles = articles.filter(article => 
      article.attributes.Domain === config.HARDCODED_DOMAIN && 
      article.attributes.urlSlug !== '/'
    );

    const paths = filteredArticles.map(article => ({
      params: { slug: article.attributes.urlSlug.replace(/^\//, '') },
    }));

    return { paths, fallback: false };
  } catch (error) {
    console.error('Error in getStaticPaths:', error);
    return { paths: [], fallback: false };
  }
}

export async function getStaticProps({ params }) {
  try {
    const res = await axios.get(config.API_URL, {
      headers: {
        Authorization: `Bearer ${config.API_TOKEN}`
      }
    });
    const allArticles = res.data.data;
    const article = allArticles.find(article => 
      article.attributes.Domain === config.HARDCODED_DOMAIN &&
      article.attributes.urlSlug.replace(/^\//, '') === params.slug
    );

    if (!article) {
      return { notFound: true };
    }

    return {
      props: {
        article,
      },
    };
  } catch (error) {
    console.error('Error in getStaticProps:', error);
    return { notFound: true };
  }
}