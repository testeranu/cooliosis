export default function Custom500() {
    return <h1>500 - Server Error</h1>;
  }